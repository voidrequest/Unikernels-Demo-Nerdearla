const http = require('http');
const os = require('os');
const Redis = require('ioredis');

const PORT = process.env.PORT || 8082;
const REDIS_URL = process.env.REDIS_URL || 'redis://127.0.0.1:6379'; 
const SERVER_ID = 'Nodo-' + Math.random().toString(36).substring(2, 6);
const ASCII_BANNER = `
=========================================
 UNIKERNEL INICIADO: ${SERVER_ID}
=========================================
`;

function getSafeMemoryUsage() {
    try {
        return process.memoryUsage();
    } catch (e) {
        return { heapTotal: 0, heapUsed: 0, external: 0, arrayBuffers: 0 };
    }
}

async function startApp() {
    const redisClient = new Redis(REDIS_URL);
    
    redisClient.on('error', (err) => console.error(`[${SERVER_ID}] Error de Redis:`, err));
    redisClient.on('connect', () => console.log(`[${SERVER_ID}] Conectado a Redis`));

    const server = http.createServer(async (req, res) => {
        
        const clientIp = req.socket.remoteAddress || 'unknown IP';
        console.log(`[${SERVER_ID}] ${new Date().toISOString()} - ${req.method} ${req.url} - IP: ${clientIp}`);

        if (req.url === '/' && req.method === 'GET') {
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Unikernels en Nerdearla</title>
                    <style>
                        body {
                            background-color: #1e1e1e;
                            color: #00ffcc;
                            font-family: 'Courier New', Courier, monospace;
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            justify-content: center;
                            height: 100vh;
                            margin: 0;
                            text-align: center;
                        }
                        h1 { font-size: 6rem; margin: 0; text-shadow: 0 0 20px #00ffcc; }
                        h2 { color: #ff00ff; font-size: 2.5rem; }
                        .node-badge { background: #ff00ff; color: white; padding: 10px 20px; border-radius: 8px; font-size: 1.5rem; margin-top: 20px; }
                        a { color: white; margin-top: 40px; font-size: 1.2rem; text-decoration: none; border-bottom: 1px dashed white; }
                        a:hover { color: #00ffcc; }
                    </style>
                </head>
                <body>
                    <h1>¡HOLA NERDEARLA!</h1>
                    <h2>Llegaron los Unikernels</h2>
                    <div class="node-badge">Atendido por: ${SERVER_ID}</div>
                    <a href="/metrics">Ver Métricas (JSON) &rarr;</a>
                </body>
                </html>
            `);
            return;
        }

        if (req.url === '/metrics' && req.method === 'GET') {
            const memoryUsage = getSafeMemoryUsage();
            const cpuUsage = process.cpuUsage();
            
            let requestCount = 'indisponible';
            
            if (redisClient.status === 'ready' || redisClient.status === 'connect') {
                try {
                    requestCount = await redisClient.incr('metrics_request_count');
                } catch (e) {
                    console.error('Error:', e);
                }
            }

            const payload = {
                timestamp: new Date().toISOString(),
                served_by: SERVER_ID,
                request_count: requestCount,
                system: {
                    uptime_seconds: os.uptime(),
                    total_memory_bytes: os.totalmem(),
                    free_memory_bytes: os.freemem(),
                    load_avg: os.loadavg()
                },
                process: { memory: memoryUsage, cpu: cpuUsage }
            };

            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(payload, null, 2));
        } else {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Endpoint no encontrado' }));
        }
    });

    server.listen(PORT, () => {
        console.log(ASCII_BANNER);
        console.log(`Escuchando en el puerto ${PORT}...`);
    });
}

startApp();
